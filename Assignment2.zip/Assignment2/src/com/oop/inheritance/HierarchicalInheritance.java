package com.oop.inheritance;

public class HierarchicalInheritance {
    public void A()
    {
    	System.out.println("method A");
    }
    //child class 1: HL1.java
    //child class 2: HL2.java
}
