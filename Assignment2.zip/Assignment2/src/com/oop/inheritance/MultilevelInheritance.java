package com.oop.inheritance;

public class MultilevelInheritance {
	public void A()
    {
    	System.out.println("method A from parent class");
    }
	//child class1 : MLClass1.java
}