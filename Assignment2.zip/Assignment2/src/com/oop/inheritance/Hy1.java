package com.oop.inheritance;

public class Hy1 extends HybridInheritance {
	void B()
	   {
		   System.out.println("method B");
	   }
}
