package com.oop.inheritance;

public class HL1 extends HierarchicalInheritance{
   public void B()
   {
	   System.out.println("method B");
   }
}
