package com.oop.inheritance;

public class SingleInheritance {
    public void dog()
    {
    	System.out.println("dog barks");
    }
    public void cat()
    {
    	System.out.println("cat meows");
    }
}//child class Base.java

