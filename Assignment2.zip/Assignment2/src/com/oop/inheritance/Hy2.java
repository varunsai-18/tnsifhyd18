package com.oop.inheritance;

public class Hy2 extends HybridInheritance{
	void C()
	   {
		   System.out.println("method C");
	   }
}
