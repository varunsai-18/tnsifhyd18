package com.oop.inheritance;

public class HybridInheritance {
   void A()
   {
	   System.out.println("method A");
   }
}
