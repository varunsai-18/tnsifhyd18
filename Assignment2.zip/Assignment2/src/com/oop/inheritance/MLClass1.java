package com.oop.inheritance;

public class MLClass1 extends MultilevelInheritance {
   public void B()
   {
	   System.out.println("method B from Child class 1");
   }
   //child class: MLClass2
}
