package com.oop.constructors;

public class CarMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Car c1=new Car();
       System.out.println(c1.run());
	}

}
