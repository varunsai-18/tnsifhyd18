package com.oop.constructors;

public class Car2Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         Car2 c1=new Car2("open","off","seated",28);
         System.out.println(c1.run());
	}

}
