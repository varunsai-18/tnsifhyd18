package com.si.pack;

public class Employee3 {
	public long salary(long s)
	   {
		   return s;
	   }
	   public String name(String n)
	   {
		   return n;
	   }
	   public int age(int a)
	   {
		   return a;
	   }
}
