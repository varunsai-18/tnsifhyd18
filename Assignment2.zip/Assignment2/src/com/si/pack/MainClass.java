package com.si.pack;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Employee1 e1=new Employee1();
       Employee2 e2=new Employee2();
       Employee3 e3=new Employee3();
       System.out.println(e1.salary(100000));
       System.out.println(e1.name("vaishu"));
       System.out.println(e1.age(21));
       System.out.println(e2.salary(150000));
       System.out.println(e2.name("chinni"));
       System.out.println(e2.age(20));
       System.out.println(e3.salary(200000));
       System.out.println(e3.name("varshu"));
       System.out.println(e3.age(22));
	}

}
