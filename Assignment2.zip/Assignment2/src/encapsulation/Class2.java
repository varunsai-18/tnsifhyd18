package encapsulation;

public class Class2 {
public static void main(String[] args) {
	Class1 c1= new Class1();
	c1.setName("vaishnavi");
	System.out.println(c1.getName());
	c1.setAge(21);
	System.out.println(c1.getAge());
	c1.setLoc("yamjal");
	System.out.println(c1.getLoc());
}
}
