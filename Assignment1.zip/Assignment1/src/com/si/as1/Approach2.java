package com.si.as1;
//accessing instance and static variables through approach2
public class Approach2 {
     int x=2;
     static String name="hello";

}
