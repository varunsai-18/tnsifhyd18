package com.si.as1;

public class College1 {
	 String name="indu";
     static String branch="ece";
     void location()
     {
   	  System.out.println("ibp");
     }
     static String affiliation()
     {
   	  return "osmania";
     }
     //accessing through class MainApproach2
}
