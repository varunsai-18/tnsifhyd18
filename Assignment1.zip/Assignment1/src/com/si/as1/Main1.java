package com.si.as1;

public class Main1 {
public static void main(String[] args) {
	Child1 c1= new Child1();
	c1.display();
}
}
