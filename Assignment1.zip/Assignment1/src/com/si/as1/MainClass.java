package com.si.as1;

public class MainClass {
	public static void main(String[] args) {
		ChildClass c= new ChildClass();
	    c.hello();
	    //child class method will be displyed
	}
    
}
