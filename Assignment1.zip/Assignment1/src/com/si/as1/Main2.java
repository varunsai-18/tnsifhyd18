package com.si.as1;

public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       //Child2 c2=new Child2();
       Child2.display();
	}

}
