package com.si.as1;

public class MainApproach {

	public static void main(String[] args) {
		int y=10;
		Approach2 a= new Approach2();
		System.out.println(y);
		System.out.println(a.x);
		System.out.println(Approach2.name);

	}
//accessing through the class MainApproach
}
