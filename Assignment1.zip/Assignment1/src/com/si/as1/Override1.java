package com.si.as1;
//can we override instance methods?
public class Override1 {
  public void display()
  {
	  System.out.println("instance method from base class");
  }
  //child class: Child1.java
}
//ANS : yes