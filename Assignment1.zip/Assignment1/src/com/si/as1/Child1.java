package com.si.as1;

public class Child1 extends Override1 {
   public void display()
   {
	   System.out.println("instance method from child class");
   }
   //main class : Main1.java
}
