package com.si.as1;

public class MainApproach2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int ID=12;
	       College1 c=new College1();
	 	  System.out.println(ID);
		  System.out.println(c.name);
		  System.out.println(College1.branch);
		  c.location();
		  System.out.println(College1.affiliation());

	}

}
