package com.si.as1;
//overriding
public class BaseClass {
   void hello()
   {
	   System.out.println("HELLO!!");
   }
   //child class:ChildClass.java
}
