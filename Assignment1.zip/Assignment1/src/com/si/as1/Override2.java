package com.si.as1;
//can we override static methods?
public class Override2 {
  static void display()
  {
	  System.out.println("static method from parent class");}
  //child class : Child2.java
}
//ANS : no

