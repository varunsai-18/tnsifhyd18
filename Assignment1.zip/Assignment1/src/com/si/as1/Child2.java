package com.si.as1;

public class Child2 extends Override2{
   // void display()
   // {
    //	System.out.println("method from child class");
    //}
    //main class : Main2
}
