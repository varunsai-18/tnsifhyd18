package com.si.as1;

public class ChildClass extends BaseClass {
	  void hello()
	  {
		  System.out.println("HELLO HELLO");
	  }
	  //main class ; MainClaa.java
	}
